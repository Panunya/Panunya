export enum PreferencesTab {
  Accounts = 0,
  Integrations = 1,
  Git = 2,
  Appearance = 3,
  Prompts = 4,
  Advanced = 5,
}
